from distutils.core import setup

setup (
    name='FirstPythonPackage',
    version='0.2.0',
    packages=['firstpythonpackage',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
