#!/bin/bash

echo "copy a file to desktop"
cp ~/test.py ~/Desktop/test.py

