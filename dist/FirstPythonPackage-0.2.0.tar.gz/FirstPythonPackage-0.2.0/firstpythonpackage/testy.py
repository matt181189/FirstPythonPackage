print "this is a test"
